# CSS Variable-Powered Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/Vilen-_boi/pen/dywdobX](https://codepen.io/Vilen-_boi/pen/dywdobX).

Design based off: https://dribbble.com/shots/2271565-Day-095-Time-is-Money